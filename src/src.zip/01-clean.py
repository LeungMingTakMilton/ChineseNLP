import sys
import unicodedata
from util.langconv import *

inputfile = str(sys.argv[1])
outputfile = str(sys.argv[2])

content=[]

with open(inputfile) as f:
    for line in f:
        line = Converter('zh-hant').convert(line.decode('utf-8'))
        content.append(line)
        
with open(outputfile,'w') as f:
    for w in content:
        # print ("%s" % w)
        f.write(w.encode('utf-8'))
        