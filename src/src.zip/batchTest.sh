INFILE=$1
MODELDIR=$2
OUTDIR=$3

CLEAN_DOC=$OUTDIR/zh.txt
SEGMENT_DOC=$OUTDIR/segment.txt
TOKEN_DOC=$OUTDIR/tokens.txt
FREQ_WORDS=$OUTDIR/freq.txt
BIGRAM=$OUTDIR/bigram.txt
TRIGRAM=$OUTDIR/trigram.txt
TFIDF=$OUTDIR/score.txt

python 01-clean.py $INFILE $CLEAN_DOC
python 02-segment.py $CLEAN_DOC $SEGMENT_DOC 
python 03-filter.py $SEGMENT_DOC $TOKEN_DOC 
python 04a-ngram.py $TOKEN_DOC $FREQ_WORDS $BIGRAM $TRIGRAM
python 04b-tfidf.py $TOKEN_DOC $MODELDIR/tfidf_dict.txt $TFIDF

